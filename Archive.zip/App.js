import React from 'react'
import Navigator from './Navigator'

const App = () => {
  return <Navigator />
}

export default App

# react-native-deep-linking
React Native deep linking simple project

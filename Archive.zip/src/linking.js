const config = {
  screens: {
    Hello: {
      path: 'hello',
    },
    World: {
      path: 'world',
    },
  },
}

const linking = {
  prefixes: ['demo//app'],
  config,
}

export default linking

import { StyleSheet, Dimensions } from 'react-native'

const win = Dimensions.get('window')
const height = win.height
const width = win.width

export default StyleSheet.create({
  NavigatorStyles: {
    backgroundColor: 'red',
    position: 'absolute',
    bottom: 50,
  },
})

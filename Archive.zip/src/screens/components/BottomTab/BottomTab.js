import React from 'react'
import { View, Text, Image } from 'react-native'
import Hello from '../../containers/Hello/Hello'
import World from '../../containers/World/World'
import Home from '../../../res/home.png'
import Notify from '../../../res/notify.png'
import styles from './styles'

import { createBottomTabNavigator } from '@react-navigation/bottom-tabs'

const Tab = createBottomTabNavigator()

const BottomTab = () => {
  return (
    <Tab.Navigator
      tabBarOptions={{
        style: {
          height: 114,
        },
        tabStyle: {
          height: 114,
          backgroundColor: '#fff',
        },
      }}
    >
      <Tab.Screen
        name="Hello"
        options={{
          headerShown: false,
          tabBarIcon: ({ focused }) => (
            <TabIcon
              text="首页"
              focused={focused}
              icon={<Image source={Home} />}
            />
          ),
        }}
        component={Hello}
      />
      <Tab.Screen
        name="World"
        options={{
          headerShown: false,
          tabBarIcon: ({ focused }) => (
            <TabIcon
              text="通知"
              focused={focused}
              icon={<Image source={Notify} />}
            />
          ),
        }}
        component={World}
      />
    </Tab.Navigator>
  )
}

const TabIcon = ({ icon, text, focused }) => {
  return (
    <View
      style={{
        alignItems: 'center',
        justifyContent: 'center',
        borderTopColor: 'transparent',
        borderTopWidth: focused ? 2 : 0,
        paddingTop: 10,
        bottom: 35,
      }}
    >
      {icon}
      <Text
        style={{
          color: focused ? 'black' : '#8E92A2',
          fontSize: 12,
          marginTop: -13,
        }}
      >
        {text}
      </Text>
    </View>
  )
}

export default BottomTab
